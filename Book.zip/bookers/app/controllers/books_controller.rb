class BooksController < ApplicationController
  def index
    @bookers = Book.all
    @booker=Book.new
  end

  def show
    @booker=Book.find(params[:id])
  end

  def new
  end
  
  def destroy
    booker= Book.find(params[:id])
    booker.destroy
    redirect_to books_path
  end
  
  def create
    @booker = Book.new(book_params)
    if @booker.save
      flash[:notice] = 'successfully：投稿が成功しました！'
      redirect_to book_path(@booker)
    else
      @bookers = Book.all
      render :index
    end
  end
  
  def edit
    @booker=Book.find(params[:id])
    
  end
  
  def update
    @booker = Book.find(params[:id])
    @booker.update(book_params)
    if @booker.save
      flash[:notice] = 'successfully：編集が成功しました！'
      redirect_to book_path(@booker)
    else
      render :edit
    end
    
  end
  #投稿するとストロングパラメータのところでエラーが出る　”the values is empty booker"
  private
  def book_params
    params.require(:book).permit(:title, :body)
  end
  
end
